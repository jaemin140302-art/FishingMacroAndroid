package com.example.fishingmacro

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 48, 32, 32)
        }
        layout.addView(TextView(this).apply {
            text = "낚시 매크로\n\n1) 다른 앱 위에 표시 권한 허용\n2) 접근성 설정에서 ‘낚시 매크로’ 켜기\n3) 플로팅 아이콘을 눌러 시작/정지\n\n주의: 게임 화면의 캐스팅 버튼 위치에 맞게 좌표를 조정해야 합니다."
            textSize = 17f
        })
        layout.addView(Button(this).apply {
            text = "화면 위 표시 권한 설정"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                } else startService(Intent(this@MainActivity, FloatingOverlayService::class.java))
            }
        })
        layout.addView(Button(this).apply {
            text = "접근성 설정 열기"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        layout.addView(Button(this).apply {
            text = "플로팅 아이콘 띄우기"
            setOnClickListener {
                if (Settings.canDrawOverlays(this@MainActivity))
                    startService(Intent(this@MainActivity, FloatingOverlayService::class.java))
            }
        })
        setContentView(layout)
    }
}
