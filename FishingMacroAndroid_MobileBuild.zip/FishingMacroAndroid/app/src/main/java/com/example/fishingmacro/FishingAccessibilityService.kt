package com.example.fishingmacro

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent

class FishingAccessibilityService : AccessibilityService() {
    companion object {
        @Volatile var instance: FishingAccessibilityService? = null
        @Volatile var running = false
        // 기본값은 화면 중앙 근처의 임시 좌표입니다. 실제 게임의 캐스팅 버튼 위치에 맞춰야 합니다.
        @Volatile var castX = 540f
        @Volatile var castY = 1500f
        @Volatile var tapX = 540f
        @Volatile var tapY = 1000f
    }
    private val handler = Handler(Looper.getMainLooper())
    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() { stopMacro() }
    override fun onDestroy() { instance = null; stopMacro(); super.onDestroy() }

    fun startMacro() {
        if (running) return
        running = true
        cycle()
    }
    fun stopMacro() {
        running = false
        handler.removeCallbacksAndMessages(null)
    }
    private fun cycle() {
        if (!running) return
        // 길게 캐스팅(2초)
        gesture(castX, castY, 2000L) {
            handler.postDelayed({
                if (!running) return@postDelayed
                // 입질 대기 5초
                handler.postDelayed({
                    if (!running) return@postDelayed
                    // 연속 터치 구간 15초: 짧은 탭을 반복
                    tapBurst(15_000L) {
                        handler.postDelayed({ cycle() }, 500L)
                    }
                }, 5000L)
            }, 100L)
        }
    }
    private fun tapBurst(totalMs: Long, done: () -> Unit) {
        val endAt = System.currentTimeMillis() + totalMs
        fun next() {
            if (!running) return
            if (System.currentTimeMillis() >= endAt) { done(); return }
            gesture(tapX, tapY, 65L) {
                handler.postDelayed({ next() }, 70L)
            }
        }
        next()
    }
    private fun gesture(x: Float, y: Float, duration: Long, onDone: () -> Unit) {
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0, duration)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(g: GestureDescription?) { onDone() }
            override fun onCancelled(g: GestureDescription?) { if (running) handler.postDelayed({ onDone() }, 150) }
        }, handler)
    }
}
